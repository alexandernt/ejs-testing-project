exports.progra = function (req, res, next) {
  res.render("progra");
};
