exports.form = function (req, res, next) {
  res.render("formulario");
};
